import xlrd
import pymysql


class InitPage:
    # wd = xlrd.open_workbook(r"D:\Python用例\自动化框架\测试用例.xlsx")
    # data = []
    # sheet = wd.sheet_by_index(0)
    # rows = sheet.nrows
    # for i in range(1, rows):
    #     rows_values = sheet.row_values(i)
    #     data.append({"username":rows_values[0],"password":rows_values[1],"expect":rows_values[2]})
    conn = pymysql.connect(host="localhost", user='root', password='root', database='hkrtest')
    cursor = conn.cursor()
    sql = "select * from teast "
    cursor.execute(sql)
    x = cursor.fetchall()
    data = []
    for i in range(len(x)):
        data.append({"username": x[i][0], "password": x[i][1], "expect": x[i][2]})

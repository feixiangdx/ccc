from unittest import TestCase
from appium import webdriver
from ddt import ddt
from ddt import data
import time
from InitPage import InitPage
from LoginOperation import LoginOpera


@ddt
class TestLogin(TestCase):
    server = r'http://localhost:4723/wd/hub'  # Appium Server, 端口默认为4723
    desired_capabilities = {
        'platformName': 'Android',  # 平台
        'deviceName': '127.0.0.1:21503',  # 逍遥模拟器端口21503、夜神62001、雷电5555
        'platformVersion': '7.1.2',  # 安卓版本
        'appPackage': 'com.sina.weibo',  # APP包名
        'appActivity': 'com.sina.weibo.SplashActivity',  # APP启动名
        # 'noReset': True,
        'unicodeKeyboard': True,  # 这句和下面那句是避免中文问题的
        'resetKeyboard': True
    }

    # 在每个操作之前先做预备工作
    def setUp(self) -> None:
        self.imgs = []
        self.driver = webdriver.Remote(self.server, self.desired_capabilities)  # 连接手机和APP
        time.sleep(3)  # 等待app启动

    # 在每个用例执行后，将app关闭
    def tearDown(self) -> None:
        time.sleep(20)
        self.driver.quit()  # 退出app

    @data(*InitPage.page)
    def testSuccessCase1(self, testdata):
        username = testdata["username"]
        password = testdata["password"]
        expect = testdata["expect"]

        loginObj = LoginOpera(self.driver)
        time.sleep(2)
        loginObj.login(username, password)

        result = loginObj.get_succes_data()
        time.sleep(1)
        if result != expect:
            self.imgs.append(self.driver.get_screenshot_as_base64())
        # 断言
        self.assertEqual(expect, result)


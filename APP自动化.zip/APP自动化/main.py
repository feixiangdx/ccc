import HTMLTestRunner
import unittest
import os

tests = unittest.defaultTestLoader.discover(os.getcwd(), pattern="Test*.py")

runner = HTMLTestRunner.HTMLTestRunner(
    title="微博登录测试",
    description="微博登陆详细测试【成功，失败】",
    verbosity=1,
    stream=open(file="微博测试报告.html", mode="w+", encoding="utf-8")
)
runner.run(tests)

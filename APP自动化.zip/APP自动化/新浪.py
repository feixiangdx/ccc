from appium import webdriver
from appium.webdriver.common.touch_action import TouchAction
import time
url = "127.0.0.1:4723/wd/hub"

param = {
    "platformName": "Android",
    "paltformVersion": "7.1.2",
    "deviceName": "127.0.0.1:62001",
    "appPackage": "com.sina.weibo",
    "appActivity": "com.sina.weibo.SplashActivity"
}

driver = webdriver.Remote(url, param)

TouchAction(driver).tap(x=573, y=1029).perform()
time.sleep(2)
el1 = driver.find_element_by_id("com.sina.weibo:id/titleBack")
el1.click()
time.sleep(10)
TouchAction(driver).tap(x=393, y=1407).perform()
time.sleep(20)
el2 = driver.find_element_by_id("com.sina.weibo:id/et_login_view_uname")
time.sleep(2)
el2.send_keys("13131215003")
el3 = driver.find_element_by_id("com.sina.weibo:id/et_login_view_psw")
el3.send_keys("cyz1999828456789")
TouchAction(driver).tap(x=101, y=1484).perform()
time.sleep(2)
TouchAction(driver).tap(x=268, y=667).perform()
time.sleep(2)
TouchAction(driver).tap(x=448, y=1261).perform()
time.sleep(10)
driver.quit()

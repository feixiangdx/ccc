class InitPage:
    page = [{"username": "13131215003", "password": "cyz1999828456789", "expect": "返回"},
            ]

'''
    unittest：单元测试框架。
    1.子类继承TestCase
    2.写测试用例,testXxx
    3.运行

'''
from unittest import TestCase
from cale import cale


class TestCalc(TestCase):

    def testAdd1(self):
        num1 = 10
        num2 = 30
        sum = 40

        calc = cale()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd2(self):
        num1 = -10
        num2 = -50
        sum = -60

        calc = cale()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd3(self):
        num1 = -10
        num2 = 50
        sum = 40

        calc = cale()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd4(self):
        num1 = 100000000000000000000000000000000000000
        num2 = 11
        sum = 100000000000000000000000000000000000011

        calc = cale()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

    def testAdd5(self):
        num1 = -100000000000000000000000000000000000000
        num2 =  100000000000000000000000000000000000000
        sum = 0

        calc = cale()
        s = calc.add(num1, num2)

        # 判断，断言
        self.assertEqual(sum, s)

# '''
#     HTMLTestRunner：运行器，可以运行和生成测试报告
# '''
import HTMLTestRunner
import unittest

tests = unittest.defaultTestLoader.discover(r"D:\Python用例\自动化", pattern="Test*.py")

runner = HTMLTestRunner.HTMLTestRunner(
    title="计算器测试报告",
    description="计算器四则运算报告",
    verbosity=1,
    stream=open(file="计算器报告.html", mode="w+", encoding="utf-8")

)
runner.run(tests)


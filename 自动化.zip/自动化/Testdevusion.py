from cale import cale
from unittest import TestCase


class TestDivision(TestCase):
    def testDivision1(self):
        num1 = 8
        num2 = 2
        division = 4
        calc = cale()
        s = calc.devision(num1, num2)
        self.assertEqual(division, s)

    def testDivision2(self):
        num1 = -8
        num2 = 2
        division = -4
        calc = cale()
        s = calc.devision(num1, num2)
        self.assertEqual(division, s)

    def testDivision3(self):
        num1 = -8
        num2 = -2
        division = -4
        calc = cale()
        s = calc.devision(num1, num2)
        self.assertEqual(division, s)

    def testDivision4(self):
        num1 = 100000000000000000000000000000000000000
        num2 = 10
        division = 10000000000000000000000000000000000000
        calc = cale()
        s = calc.devision(num1, num2)
        self.assertEqual(division, s)

from cale import cale
from unittest import TestCase


class TestMulti(TestCase):
    def testMulti1(self):
        num1 = 2
        num2 = 4
        multi = 8
        calc = cale()
        s = calc.multi(num1, num2)
        self.assertEqual(multi, s)

    def testMulti2(self):
        num1 = -2
        num2 = 4
        multi = -8
        calc = cale()
        s = calc.multi(num1, num2)
        self.assertEqual(multi, s)

    def testMulti3(self):
        num1 = -2
        num2 = -4
        multi = 8
        calc = cale()
        s = calc.multi(num1, num2)
        self.assertEqual(multi, s)

    def testMulti4(self):
        num1 = 10000000000000000000000000000000000000000000000
        num2 = 10
        multi = 100000000000000000000000000000000000000000000000
        calc = cale()
        s = calc.multi(num1, num2)
        self.assertEqual(multi, s)

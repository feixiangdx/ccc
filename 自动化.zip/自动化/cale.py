class cale:
    def add(self, a, b):
        return a + b

    def minus(self, a, b):
        return a - b

    def multi(self, a, b):
        return a * b

    def devision(self, a, b):
        return a / b

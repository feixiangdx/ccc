from cale import cale
from unittest import TestCase


class TestMinus(TestCase):
    def testMinus1(self):
        num1 = 50
        num2 = 10
        minuse = 40
        calc = cale()
        s = calc.minus(num1, num2)

        self.assertEqual(minuse, s)

    def testMinus2(self):
        num1 = -15
        num2 = -20
        minuse = 10
        calc = cale()
        s = calc.minus(num1, num2)

        self.assertEqual(minuse, s)

    def testMinus3(self):
        num1 = -50
        num2 = 10
        minuse = -60
        calc = cale()
        s = calc.minus(num1, num2)

        self.assertEqual(minuse, s)

    def testMinus4(self):
        num1 = 60
        num2 = -100
        minuse = 160
        calc = cale()
        s = calc.minus(num1, num2)

        self.assertEqual(minuse, s)

    def testMinus5(self):
        num1 = 1000000000000000000000000000000000000000000000000
        num2 = 1000000000000000000000000000000000000000000000000
        minuse = 0
        calc = cale()
        s = calc.minus(num1, num2)

        self.assertEqual(minuse, s)


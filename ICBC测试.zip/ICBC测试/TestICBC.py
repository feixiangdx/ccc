"""
    参数化：
        DDT:data driven test
    1.unittest
    2.ddt (修饰类)    data（引入数据源）    unpack（解包）
任务1：
    将数据库源集中存储在excel表中，xlrd读取数据，实现参数化
任务2：
    对银行5大模块进行参数化，参数化的数据放在excel表里。
"""

from unittest import TestCase
from ddt import ddt
from ddt import data
from ddt import unpack
from ICBC import add_user
import xlrd


# # 开户测试
da = []
wd = xlrd.open_workbook(r"D:\Python用例\ICBC测试\ICBC.xlsx")
sheet = wd.sheet_by_index(0)
rows = sheet.nrows
for i in range(rows):
    row_values = sheet.row_values(i)
    da.append([{"account": row_values[0], "username": row_values[1], "password": row_values[2],
                "province": row_values[3], "country": row_values[4], "street": row_values[5],
                "door": row_values[6], "deposit": row_values[7]}, row_values[8]])


@ddt
class TestICBC(TestCase):
    @data(*da[0:4])
    @unpack
    def testAddUser(self, t_list, h):
        s = add_user(t_list)
        self.assertEqual(s, h)










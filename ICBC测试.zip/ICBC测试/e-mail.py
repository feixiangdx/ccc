from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
import smtplib
#
f = open("银行报告.html", 'rb',).read()
# f.close()
att = MIMEText(f, 'base64', 'utf-8')
att['content-type'] = 'application/octet-stream'
att['content-disposition'] = "attachment; filename =testing_result.html"
msg = MIMEText('陈宇郑', 'plain', 'utf-8')

msg_all = MIMEMultipart('related')
msg_all['Subject'] = Header('自动化测试报告', "utf-8")

print('添加附件')
msg_all.attach(att)
print('添加成功')
msg_all.attach(msg)

smtp = smtplib.SMTP()
smtp.connect('smtp.qq.com', 25)
smtp = smtplib.SMTP()
smtp.connect('smtp.qq.com', 25)
smtp.login('1523529388@qq.com', 'luviikfsvikafgfe')
smtp.sendmail('1523529388@qq.com', '13552648187@163.com', msg_all.as_string())
smtp.quit()
print('email has send out!')
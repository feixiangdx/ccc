from unittest import TestCase

import xlrd
from ddt import ddt
from ddt import data
from ddt import unpack
from ICBC import save_money
# 存钱测试
wd = xlrd.open_workbook(r"D:\Python用例\ICBC测试\ICBC.xlsx")
save = []
sheet = wd.sheet_by_index(1)
rows = sheet.nrows
for x in range(rows):
    save.append(sheet.row_values(x))
@ddt
class TestICBC(TestCase):
    @data(*save[0:rows])
    @unpack
    def testSaveMoney(self, a, b, c):
        s = save_money(a, b)
        self.assertEqual(s, c)

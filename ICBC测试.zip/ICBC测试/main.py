import HTMLTestRunner
import unittest
import os

test = unittest.defaultTestLoader.discover(os.getcwd(), pattern="Test*.py")

runner = HTMLTestRunner.HTMLTestRunner(
    title="ICBC银行测试报告",
    description="银行报告",
    verbosity=1,
    stream=open(file="银行报告.html", mode="w+", encoding="utf-8")

)
runner.run(test)

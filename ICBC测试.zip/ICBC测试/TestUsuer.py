from unittest import TestCase
from ddt import ddt
from ddt import data
from ddt import unpack
from ICBC import user
import xlrd

# 查询
wd = xlrd.open_workbook(r"D:\Python用例\ICBC测试\ICBC.xlsx")
uer = []
sheet = wd.sheet_by_index(4)
rows = sheet.nrows
for q in range(rows):
    uer.append(sheet.row_values(q))


@ddt
class TestICBC(TestCase):
    @data(*uer[0:rows])
    @unpack
    def testUser(self, a, b, c):
        s = user(a, b)
        self.assertEqual(s, c)

from unittest import TestCase
import xlrd
from ddt import ddt
from ddt import data
from ddt import unpack
from ICBC import transfer

# 转账
wd = xlrd.open_workbook(r"D:\Python用例\ICBC测试\ICBC.xlsx")
transfer_money = []
sheet = wd.sheet_by_index(3)
rows = sheet.nrows
for u in range(rows):
    transfer_money.append(sheet.row_values(u))


@ddt
class TestICBC(TestCase):
    @data(*transfer_money[0:rows])
    @unpack
    def testTransfer(self, a, b, c, d, f):
        s = transfer(a, b, c, d)
        self.assertEqual(s, f)

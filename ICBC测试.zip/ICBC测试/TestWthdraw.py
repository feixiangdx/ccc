from unittest import TestCase
import xlrd
from ddt import ddt
from ddt import data
from ddt import unpack
from ICBC import withdraw_money

#  取钱
wd = xlrd.open_workbook(r"D:\Python用例\ICBC测试\ICBC.xlsx")
withdraw = []
sheet = wd.sheet_by_index(2)
rows = sheet.nrows
for z in range(rows):
    withdraw.append(sheet.row_values(z))


@ddt
class TestICBC(TestCase):
    @data(*withdraw[0:rows])
    @unpack
    def testWithdrawMoney(self, a, b, c, d):
        s = withdraw_money(a, b, c)
        self.assertEqual(s, d)